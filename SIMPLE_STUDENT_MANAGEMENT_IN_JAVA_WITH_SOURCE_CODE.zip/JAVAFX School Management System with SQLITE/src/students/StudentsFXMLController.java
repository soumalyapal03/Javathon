package students;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;

public class StudentsFXMLController
  implements Initializable
{
  @FXML
  private AnchorPane StudentPane;
  
  public void initialize(URL url, ResourceBundle rb) {}
}